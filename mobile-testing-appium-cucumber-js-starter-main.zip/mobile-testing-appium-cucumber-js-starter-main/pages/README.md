# pages directory

Define application pages in this directory.

> Please delete this file if unused.

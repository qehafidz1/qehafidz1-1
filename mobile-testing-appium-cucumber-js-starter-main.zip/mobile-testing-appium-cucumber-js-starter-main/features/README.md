# features directory

Put `.feature` files in this directory.

> Please delete this file if unused.

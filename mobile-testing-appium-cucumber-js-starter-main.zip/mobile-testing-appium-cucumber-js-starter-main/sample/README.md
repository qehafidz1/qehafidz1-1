# sample directory

Put sample mobile application for testing in this directory.

> Please delete this file if unused.
